# HarukinLogo

This files is Harukin's service logo.

## License

CC BY 4.0